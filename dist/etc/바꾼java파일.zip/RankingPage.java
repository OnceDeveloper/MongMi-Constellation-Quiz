import java.awt.*;
import java.awt.Toolkit;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.sound.sampled.*; 
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


class RankingPage extends JFrame implements ActionListener
{
	
	JPanel contentPane, panel1 ;
	JLabel backLabel, firstPlace, secondPlace, thirdPlace;
	JButton button;
	Font font = new Font("����ǹ��� �־�", Font.BOLD, 20);

	MyScore ms;
	Socket s;
	DataInputStream dis;
	DataOutputStream dos;
	String firstPlace_id;
	int firstPlace_score;
	String secondPlace_id;
	int secondPlace_score;
	String thirdPlace_id;
	int thirdPlace_score;

	RankingPage(MyScore ms, Socket s){

		this.ms = ms;
		this.s = s;
		this.dis = ms.dis;
		this.dos = ms.dos;
		//this.score = ms.score;
		
		contentPane = new JPanel();
		panel1 = new JPanel();
		button = new JButton(new ImageIcon("img/button/MainB.png"));
		firstPlace = new JLabel("", JLabel.CENTER);
		secondPlace = new JLabel("", JLabel.CENTER);
		thirdPlace = new JLabel("", JLabel.CENTER);

		firstPlace.setFont(font);
		secondPlace.setFont(font);
		thirdPlace.setFont(font);
		playSound("eff_grow_shine.wav");
		
	}

	void init(){ 
		
		//dataIN();
		testIn();

		contentPane.setBorder(null);
		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
		contentPane.setOpaque(true);
		
		panel1.setOpaque(true);		
		contentPane.add(panel1);
		panel1.setLayout(null);

		backLabel = new JLabel(new ImageIcon("img/background/Rank.png"));
		backLabel.setBounds(0, 0, 350, 550);
		backLabel.setOpaque(true);
		panel1.add(backLabel);

		firstPlace.setBounds(140, 183, 182, 61);
		firstPlace.setText(firstPlace_id+" ("+firstPlace_score+"��)");
		backLabel.add(firstPlace);
		
		secondPlace.setBounds(140, 269, 182, 61);
		secondPlace.setText(secondPlace_id+" ("+secondPlace_score+"��)");
		backLabel.add(secondPlace);

		thirdPlace.setBounds(140, 360, 182, 61);
		thirdPlace.setText(thirdPlace_id+" ("+thirdPlace_score+"��)");
		backLabel.add(thirdPlace);
		

		button.setBounds(59, 450, 265, 80);
		backLabel.add(button);
		button.setFocusPainted(false);
		button.setBorderPainted(false);
		button.setContentAreaFilled(false);
		button.setPressedIcon(new ImageIcon("img/button/MainBC.png"));
		//button.setOpaque(false);
		button.addActionListener(this);


		setUI();
	}

	void setUI(){
		setTitle("���� �ʼ�����");
		setSize(357, 570);
		setVisible(true);
		setLocation(200,100);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	void dataIN(){
		try{
			for(int i = 0; i<6; i++){
				String nameT = dis.readUTF();
				if(nameT.startsWith("#name")){
					String str = nameT.trim();
					str = str.substring(nameT.indexOf(" "), str.length());
					if(i==0){
						firstPlace_id = str;
					}else if(i==2){
						secondPlace_id = str;
					}else if(i==4){
						thirdPlace_id = str;
					}
				}else if(nameT.startsWith("#rank")){
					String str = nameT.trim();
					str = str.substring(nameT.indexOf(" "), str.length());
					int tempNum = Integer.parseInt(str);
					if(i==1){
						firstPlace_score = tempNum;
					}else if(i==3){
						secondPlace_score = tempNum;
					}else if(i==5){
						thirdPlace_score = tempNum;
					}
				}
			}
		}catch(NumberFormatException ne){
		}catch(IOException ie){}

	}

	void testIn(){
		try{
			firstPlace_id = dis.readUTF();
			firstPlace_score = Integer.parseInt(dis.readUTF());
			secondPlace_id = dis.readUTF();
			secondPlace_score = Integer.parseInt(dis.readUTF());
			thirdPlace_id = dis.readUTF();
			thirdPlace_score = Integer.parseInt(dis.readUTF());
		}catch(NumberFormatException ne){
		}catch(IOException ie){}
	}

	static void playSound(String filename){ 
		File file = new File("bgm/" + filename);
		if(file.exists()){ 
			try{
				AudioInputStream stream = AudioSystem.getAudioInputStream(file);
				Clip clip = AudioSystem.getClip();
				clip.open(stream);
				clip.start();
			}catch(Exception e){
				e.printStackTrace();
			}
		}else{ 
			System.out.println("File Not Found!");
		}
	}	

	@Override
	public void actionPerformed(ActionEvent e){
		Object obj = e.getSource();
		if(obj == button){
			button.setEnabled(false);
			setVisible(false);
			dispose();
			System.exit(0);
			//new MainPage().init(); ����ŷ���� ��ư(����) ������ main �������� �̵�
		}else{}
	}

}

////////////////////////////////////////////////////////////////////////////////////////////


